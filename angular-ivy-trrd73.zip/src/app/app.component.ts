import { Component, VERSION } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Archis\'s Calculator App';
  public n1:number;
  public n2:number;
  public res:number;

  add()
  {
    this.res = this.n1+this.n2;
  }
  sub()
  {
    this.res = this.n1-this.n2;
  }
  mul()
  {
    this.res = this.n1*this.n2;
  }
  div()
  {
    this.res=this.n1/this.n2;
  }
  display()
  {
    {{this.res}}
  }
}
